﻿using System;

class Program
{
    static void Main()
    {

        Console.OutputEncoding = System.Text.Encoding.UTF8;

        // Введення кількості елементів
        Console.Write("Введіть кількість елементів масивів N: ");
        int N = int.Parse(Console.ReadLine());

        // Оголошення масивів
        int[] A = new int[N];
        int[] B = new int[N];

        // Введення елементів масиву A
        Console.WriteLine("\nВведіть елементи масиву A:");
        for (int i = 0; i < N; i++)
        {
            Console.Write($"A[{i}] = ");
            A[i] = int.Parse(Console.ReadLine());
        }

        // Введення елементів масиву B
        Console.WriteLine("\nВведіть елементи масиву B:");
        for (int i = 0; i < N; i++)
        {
            Console.Write($"B[{i}] = ");
            B[i] = int.Parse(Console.ReadLine());
        }

        // Ініціалізація змінних для пошуку
        int maxA = A[0]; // максимальне значення масиву A
        int minB = B[0]; // мінімальне значення масиву B

        // Знаходження максимального у A
        for (int i = 1; i < N; i++)
        {
            if (A[i] > maxA)
                maxA = A[i];
        }

        // Знаходження мінімального у B
        for (int i = 1; i < N; i++)
        {
            if (B[i] < minB)
                minB = B[i];
        }

        // Виведення результату
        Console.WriteLine($"\nМаксимальне значення у масиві A: {maxA}");
        Console.WriteLine($"Мінімальне значення у масиві B: {minB}");
    }
}
